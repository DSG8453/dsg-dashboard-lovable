// DSG Transport Secure Login - Popup (minimal)
// No functionality needed - just displays info
